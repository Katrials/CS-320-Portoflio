package contactService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    @DisplayName("Contact ID cannot have more than 10 characters")
    void testContactIDWithMoreThanTenCharacters() {
        Contact contact = new Contact("FirstName", "LastName", "PhoneNumbr", "Address");
        assertTrue(contact.getContactID().length() <= 10, "Contact ID has more than 10 characters.");
    }

    @Test
    @DisplayName("Contact First Name cannot have more than 10 characters")
    void testContactFirstNameWithMoreThanTenCharacters() {
        Contact contact = new Contact("Random", "LastName", "PhoneNumbr", "Address");
        assertTrue(contact.getFirstName().length() <= 10, "First Name has more than 10 characters.");
    }

    @Test
    @DisplayName("Contact Last Name cannot have more than 10 characters")
    void testContactLastNameWithMoreThanTenCharacters() {
        Contact contact = new Contact("FirstName", "Random", "PhoneNumbr", "Address");
        assertTrue(contact.getLastName().length() <= 10, "Last Name has more than 10 characters.");
    }

    @Test
    @DisplayName("Contact phone number is exactly 10 characters")
    void testContactNumberWithMoreThanTenCharacters() {
        Contact contact = new Contact("FirstName", "LastName", "5555555555", "Address");
        assertEquals(10, contact.getPhoneNumber().length(), "Phone number length does not equal 10.");
    }

    @Test
    @DisplayName("Contact address cannot have more than 30 characters")
    void testContactAddressWithMoreThanThirtyCharacters() {
        Contact c1 = new Contact("FirstName", "LastName", "value is", "PhoneNumbr");
        System.out.println("contact address i ---------" + c1.getAddress().length());
        System.out.println("contact address i ---------" + c1.getAddress());
        System.out.println(c1);
        assertTrue(c1.getAddress().length() <= 30, "Address has more than 30 characters.");
    }

    @Test
    @DisplayName("Contact First Name shall not be null")
    void testContactFirstNameNotNull() {
        Contact contact = new Contact(null, null, null, null);
        assertNull(contact.getFirstName(), "First name was not null.");
    }

    @Test
    @DisplayName("Contact Last Name shall not be null")
    void testContactLastNameNotNull() {
        Contact contact = new Contact(null, null, null, null);
        assertNull(contact.getLastName(), "Last name was not null.");
    }

    @Test
    @DisplayName("Contact Phone Number shall not be null")
    void testContactPhoneNotNull() {
        Contact contact = new Contact("FirstName", "LastName", null, "Address");
        assertNull(contact.getPhoneNumber(), "Phone number was not null.");
    }

    @Test
    @DisplayName("Contact Address shall not be null")
    void testContactAddressNotNull() {
        Contact contact = new Contact(null, null, null, null);
        assertNull(contact.getAddress(), "Address was not null.");
    }
}
}