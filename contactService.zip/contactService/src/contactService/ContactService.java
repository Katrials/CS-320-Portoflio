package contactService;

import java.util.ArrayList;

public class ContactService {
	  private ArrayList<Contact> contacts;

	    public ContactService() {
	        contacts = new ArrayList<>();
	    }

	    //ability to add, remove, or update contacts
	    public boolean addContact(Contact contact) {
	        boolean contactAlready = false;
	        for (Contact contactList : contacts) {
	            //test to see if already a contact
	            if (contactList.equals(contact)) {
	                contactAlready = true;
	            }
	        }
	        //ability to recognize if there is an existing contact
	        if (!contactAlready) {
	            contacts.add(contact);
	            return true;
	        } else {
	            return false;
	        }
	    }

	    public boolean deleteContact(String string) {
	        //run through contact list
	        for (Contact contactList : contacts) {
	            //if equals to contactID will remove and return
	            if (contactList.getContactID().equals(string)) {
	                contacts.remove(contactList);
	                return true;
	            }
	        }
	        return false;
	    }

	    public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber,
	            String address) {
	        //looping
	        for (Contact contactList : contacts) {
	            if (contactList.getContactID().equals(contactID)) {
	                if (!firstName.equals("") && !(firstName.length() > 10)) {
	                    contactList.setFirstName(firstName);
	                }
	                if (!lastName.equals("") && !(lastName.length() > 10)) {
	                    contactList.setFirstName(lastName);
	                }
	                if (!phoneNumber.equals("") && (phoneNumber.length() == 10)) {
	                    contactList.setFirstName(phoneNumber);
	                }
	                if (!address.equals("") && !(address.length() > 30)) {
	                    contactList.setFirstName(address);
	                }
	                return true;
	            }
	        }
	        return false;
	    }
	}
}
