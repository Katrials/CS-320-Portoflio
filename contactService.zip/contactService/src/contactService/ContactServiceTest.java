package contactService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
    public void testAdd() {
        ContactService cs = new ContactService();
        Contact test1 = new Contact("1413252", "Jane", "Doe", "7777777777");
        assertEquals(true, cs.addContact(test1));
    }

    @Test
    public void testDelete() {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1413252", "Mary", "Sue", "7777777777");
        Contact test2 = new Contact("1309403", "Gary", "Stew", "2187123404");
        Contact test3 = new Contact("9752319", "Vincent", "Valentine", "9215501793");

        cs.addContact(test1);
        cs.addContact(test2);
        cs.addContact(test3);

        assertEquals(true, cs.deleteContact("1309403"));
        assertEquals(false, cs.deleteContact("1309404"));
        assertEquals(false, cs.deleteContact("1309403"));
    }

    @Test
    public void testUpdate() {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1413252", "Mary", "Sue", "7777777777");
        Contact test2 = new Contact("1309403", "Gary", "Stew", "2187123404");
        Contact test3 = new Contact("9752319", "Vincent", "Valentine", "9215501793");

        cs.addContact(test1);
        cs.addContact(test2);
        cs.addContact(test3);

        assertEquals(true, cs.updateContact("9752319", "VincentFirst", "ValentineLast", "9215501793", "Advent road"));
        assertEquals(false, cs.updateContact("9752322", "VincentFirst", "ValentineLast", "9215501793", "Advent road"));
    }

}